export * as authController from "./auth.controller";
export * as loanController from "./loan.controllers";
