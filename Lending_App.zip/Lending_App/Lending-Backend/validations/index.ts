export * as authValidation from "./auth.validation";
export * as loanValidation from "./loan.validation";
