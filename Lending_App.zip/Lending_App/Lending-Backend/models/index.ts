import user from "./user.model";
import loan from "./loan.model";

export const User = user;
export const Loan = loan;
