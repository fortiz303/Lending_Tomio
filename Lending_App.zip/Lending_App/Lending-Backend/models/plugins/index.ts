import json from "./toJSON";
import page from "./paginate";

export const toJSON = json;
export const paginate = page;
