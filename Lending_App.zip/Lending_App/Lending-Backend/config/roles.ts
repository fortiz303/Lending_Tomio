export const roles = ["user"];

export const rights = new Map();

rights.set(roles[0], ["loan"]);
