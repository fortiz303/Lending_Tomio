import { combineReducers } from "redux";

import signup from "./signup";

export default combineReducers({ signup });
